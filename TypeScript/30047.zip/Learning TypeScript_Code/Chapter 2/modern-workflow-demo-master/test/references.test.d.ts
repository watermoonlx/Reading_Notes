// 3th party
///<reference path="../typings/bluebird/bluebird.d.ts" />
///<reference path="../typings/jquery/jquery.d.ts" />
///<reference path="../typings/lodash/lodash.d.ts" />
///<reference path="../typings/handlebars/handlebars.d.ts" />
///<reference path="../typings/mocha/mocha.d.ts" />
///<reference path="../typings/chai/chai.d.ts" />
///<reference path="../typings/sinon/sinon.d.ts" />

// App
///<reference path="../source/ts/model.ts" />
///<reference path="../source/ts/view.ts" />
///<reference path="../source/ts/footer_view.ts" />
///<reference path="../source/ts/header_view.ts" />
///<reference path="../source/ts/loading_view.ts" />
