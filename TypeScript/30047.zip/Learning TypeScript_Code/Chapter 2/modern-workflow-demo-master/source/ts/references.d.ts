// 3th party
///<reference path="../../typings/bluebird/bluebird.d.ts" />
///<reference path="../../typings/jquery/jquery.d.ts" />
///<reference path="../../typings/lodash/lodash.d.ts" />
///<reference path="../../typings/handlebars/handlebars.d.ts" />

// App
///<reference path="model.ts" />
///<reference path="view.ts" />
///<reference path="footer_view.ts" />
///<reference path="header_view.ts" />
///<reference path="loading_view.ts" />
