///<reference path="./references.d.ts" />

import View = require('./view');

var footerView = new View("./source/hbs/layout/footer.hbs", "#footer", null);

export = footerView;
