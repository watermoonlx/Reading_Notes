/// <reference path="./chai/chai.d.ts" />
/// <reference path="./mocha/mocha.d.ts" />
/// <reference path="./sinon/sinon.d.ts" />
/// <reference path="./jquery/jquery.d.ts" />
