# TsStock
A typeScript single-page web application
